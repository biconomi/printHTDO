;
; Driver Installer Section (For DrvInst)
;
; Copyright (c) 2007-2024 RICOH COMPANY, LTD
; All Rights Reserved
;

[DrvInst]
DrvInst=Gestetner MP C3003 PCL 6,Gestetner MP C3503 PCL 6,Gestetner DSc1030 PCL 6,infotec MP C3003 PCL 6,infotec MP C3503 PCL 6,LANIER MP C3003 PCL 6,LANIER MP C3503 PCL 6,NRG MP C3003 PCL 6,NRG MP C3503 PCL 6,RICOH MP C3003 PCL 6,RICOH MP C3503 PCL 6,SAVIN MP C3003 PCL 6,SAVIN MP C3503 PCL 6
Comment="PCL6 Driver (For Windows)"
DriverType=PCL6
DriverArchitecture=ARC2010ALFA
Version=3
IniFileName=rpdinstv.ini,allusers
IniFileSupport=3
ScenarioInstallOK=ON
RConfigFileOSVersion=3
DriverVersion=3.0.0.0
Platform=NTamd64
RCFFormatVersion=1.0
UserCodeOK=ON
ModelName.Gestetner MP C3003 PCL 6 = "MP C3003"
ModelName.Gestetner MP C3503 PCL 6 = "MP C3503"
ModelName.Gestetner DSc1030 PCL 6 = "DSc1030"
ModelName.infotec MP C3003 PCL 6 = "MP C3003"
ModelName.infotec MP C3503 PCL 6 = "MP C3503"
ModelName.LANIER MP C3003 PCL 6 = "MP C3003"
ModelName.LANIER MP C3503 PCL 6 = "MP C3503"
ModelName.NRG MP C3003 PCL 6 = "MP C3003"
ModelName.NRG MP C3503 PCL 6 = "MP C3503"
ModelName.RICOH MP C3003 PCL 6 = "MP C3003"
ModelName.RICOH MP C3503 PCL 6 = "MP C3503"
ModelName.SAVIN MP C3003 PCL 6 = "MP C3003"
ModelName.SAVIN MP C3503 PCL 6 = "MP C3503"
USBPermit=ON
PackageInstall=ON
NXIdentify=1
